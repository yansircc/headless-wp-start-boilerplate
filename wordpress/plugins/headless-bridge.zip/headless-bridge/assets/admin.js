/**
 * Headless Bridge Admin Scripts
 */
(function ($) {
  "use strict";

  function showResult($el, type, message) {
    $el.removeClass("success error loading").addClass(type).html(message).show();
  }

  function setButtonLoading($btn, loading) {
    if (loading) {
      $btn.data("original-html", $btn.html());
      $btn
        .prop("disabled", true)
        .html('<span class="dashicons dashicons-update spin"></span> Please wait...');
    } else {
      $btn.prop("disabled", false).html($btn.data("original-html"));
    }
  }

  // Test Webhook
  $("#test-webhook").on("click", function () {
    var $btn = $(this);
    var $result = $("#webhook-result");

    setButtonLoading($btn, true);
    showResult($result, "loading", "Sending test webhook...");

    $.ajax({
      url: headlessBridge.ajaxUrl,
      type: "POST",
      data: {
        action: "headless_bridge_test_webhook",
        nonce: headlessBridge.nonce,
      },
      success: function (response) {
        setButtonLoading($btn, false);
        if (response.success) {
          showResult($result, "success", response.data.message);
        } else {
          showResult($result, "error", response.data.message || "Test failed");
        }
      },
      error: function () {
        setButtonLoading($btn, false);
        showResult($result, "error", "Request failed. Check console for details.");
      },
    });
  });

  // Full Sync
  $("#full-sync").on("click", function () {
    var $btn = $(this);
    var $result = $("#sync-result");

    if (
      !confirm(
        "This will sync all content to KV cache. This may take a moment. Continue?"
      )
    ) {
      return;
    }

    setButtonLoading($btn, true);
    showResult($result, "loading", "Syncing all content to KV cache...");

    $.ajax({
      url: headlessBridge.ajaxUrl,
      type: "POST",
      data: {
        action: "headless_bridge_full_sync",
        nonce: headlessBridge.nonce,
      },
      timeout: 120000, // 2 minutes
      success: function (response) {
        setButtonLoading($btn, false);
        if (response.success) {
          var msg = response.data.message;
          if (response.data.details && response.data.details.synced) {
            msg +=
              "<br><small>Keys: " +
              response.data.details.synced.join(", ") +
              "</small>";
          }
          showResult($result, "success", msg);
        } else {
          showResult($result, "error", response.data.message || "Sync failed");
        }
      },
      error: function (xhr, status, error) {
        setButtonLoading($btn, false);
        var msg = "Request failed";
        if (status === "timeout") {
          msg = "Request timed out. The sync may still be running.";
        } else if (error) {
          msg += ": " + error;
        }
        showResult($result, "error", msg);
      },
    });
  });

  // Add spinning animation for loading state
  $("<style>")
    .text(
      "@keyframes hb-spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } } .dashicons.spin { animation: hb-spin 1s linear infinite; }"
    )
    .appendTo("head");
})(jQuery);
