<?php
/**
 * Plugin Loader
 */

defined('ABSPATH') || exit;

class Headless_Bridge_Loader {
    private static bool $initialized = false;

    public static function init(): void {
        if (self::$initialized) {
            return;
        }
        self::$initialized = true;

        require_once HEADLESS_BRIDGE_PATH . 'includes/class-acf-sync.php';
        require_once HEADLESS_BRIDGE_PATH . 'includes/class-webhook.php';
        require_once HEADLESS_BRIDGE_PATH . 'includes/class-admin.php';

        Headless_Bridge_ACF_Sync::init();
        Headless_Bridge_Webhook::init();

        if (is_admin()) {
            Headless_Bridge_Admin::init();
        }
    }
}
