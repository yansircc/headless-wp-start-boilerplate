<?php
/**
 * Plugin Loader
 */

defined('ABSPATH') || exit;

class Headless_Bridge_Loader {
    private static bool $initialized = false;

    public static function init(): void {
        if (self::$initialized) {
            return;
        }
        self::$initialized = true;

        // Core modules
        require_once HEADLESS_BRIDGE_PATH . 'includes/class-acf-sync.php';
        require_once HEADLESS_BRIDGE_PATH . 'includes/class-webhook.php';
        require_once HEADLESS_BRIDGE_PATH . 'includes/class-admin.php';

        Headless_Bridge_ACF_Sync::init();
        Headless_Bridge_Webhook::init();

        if (is_admin()) {
            Headless_Bridge_Admin::init();
        }

        // Polylang integration (only if Polylang is active)
        if (defined('POLYLANG_VERSION')) {
            require_once HEADLESS_BRIDGE_PATH . 'includes/class-polylang-slug.php';
            Headless_Bridge_Polylang_Slug::init();

            // GraphQL Polylang integration (only if WPGraphQL is active)
            if (class_exists('WPGraphQL')) {
                require_once HEADLESS_BRIDGE_PATH . 'includes/graphql/class-graphql-polylang.php';
                Headless_Bridge_GraphQL_Polylang::init();
            }
        }
    }
}
