<?php
/**
 * Language Root Queries - Add languages and defaultLanguage to RootQuery
 */

defined('ABSPATH') || exit;

use GraphQLRelay\Relay;

class Headless_Bridge_Language_Queries {

    public static function init(): void {
        add_action('graphql_register_types', [self::class, 'register_types']);
    }

    public static function register_types(): void {
        // languages query
        register_graphql_field('RootQuery', 'languages', [
            'type' => ['list_of' => 'Language'],
            'description' => __('List available languages', 'headless-bridge'),
            'resolve' => function ($source, $args, $context, $info) {
                $fields = $info->getFieldSelection();

                $languages = array_map(function ($code) {
                    return [
                        'id' => Relay::toGlobalId('Language', $code),
                        'code' => $code,
                        'slug' => $code,
                    ];
                }, pll_languages_list());

                if (isset($fields['name'])) {
                    foreach (pll_languages_list(['fields' => 'name']) as $index => $name) {
                        $languages[$index]['name'] = $name;
                    }
                }

                if (isset($fields['locale'])) {
                    foreach (pll_languages_list(['fields' => 'locale']) as $index => $locale) {
                        $languages[$index]['locale'] = $locale;
                    }
                }

                if (isset($fields['homeUrl'])) {
                    foreach ($languages as &$language) {
                        $language['homeUrl'] = pll_home_url($language['slug']);
                    }
                }

                return $languages;
            },
        ]);

        // defaultLanguage query
        register_graphql_field('RootQuery', 'defaultLanguage', [
            'type' => 'Language',
            'description' => __('Get the default language', 'headless-bridge'),
            'resolve' => function ($source, $args, $context, $info) {
                $fields = $info->getFieldSelection();
                $language = [];

                if (Headless_Bridge_GraphQL_Helpers::uses_slug_based_field($fields)) {
                    $language['code'] = pll_default_language('slug');
                    $language['id'] = Relay::toGlobalId('Language', $language['code']);
                    $language['slug'] = $language['code'];
                }

                if (isset($fields['name'])) {
                    $language['name'] = pll_default_language('name');
                }

                if (isset($fields['locale'])) {
                    $language['locale'] = pll_default_language('locale');
                }

                if (isset($fields['homeUrl'])) {
                    $language['homeUrl'] = pll_home_url($language['slug'] ?? pll_default_language('slug'));
                }

                return $language;
            },
        ]);
    }
}
