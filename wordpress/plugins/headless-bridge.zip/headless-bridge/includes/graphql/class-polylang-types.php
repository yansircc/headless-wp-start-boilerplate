<?php
/**
 * Register Polylang GraphQL types
 */

defined('ABSPATH') || exit;

class Headless_Bridge_Polylang_Types {

    public static function init(): void {
        add_action('graphql_register_types', [self::class, 'register_types'], 9);
    }

    public static function register_types(): void {
        $language_codes = [];

        foreach (pll_languages_list() as $lang) {
            $language_codes[strtoupper($lang)] = [
                'value' => $lang,
            ];
        }

        if (empty($language_codes)) {
            $locale = get_locale();
            $language_codes[strtoupper($locale)] = [
                'value' => $locale,
                'description' => __('The default locale of the site', 'headless-bridge'),
            ];
        }

        register_graphql_enum_type('LanguageCodeEnum', [
            'description' => __('Enum of all available language codes', 'headless-bridge'),
            'values' => $language_codes,
        ]);

        register_graphql_enum_type('LanguageCodeFilterEnum', [
            'description' => __('Filter by language code, default language, or all languages', 'headless-bridge'),
            'values' => array_merge($language_codes, [
                'DEFAULT' => ['value' => 'default'],
                'ALL' => ['value' => 'all'],
            ]),
        ]);

        register_graphql_object_type('Language', [
            'description' => __('Language (Polylang)', 'headless-bridge'),
            'fields' => [
                'id' => [
                    'type' => ['non_null' => 'ID'],
                    'description' => __('Language ID', 'headless-bridge'),
                ],
                'name' => [
                    'type' => 'String',
                    'description' => __('Human readable language name', 'headless-bridge'),
                ],
                'code' => [
                    'type' => 'LanguageCodeEnum',
                    'description' => __('Language code', 'headless-bridge'),
                ],
                'locale' => [
                    'type' => 'String',
                    'description' => __('Language locale', 'headless-bridge'),
                ],
                'slug' => [
                    'type' => 'String',
                    'description' => __('Language term slug', 'headless-bridge'),
                ],
                'homeUrl' => [
                    'type' => 'String',
                    'description' => __('Language front page URL', 'headless-bridge'),
                ],
            ],
        ]);
    }
}
