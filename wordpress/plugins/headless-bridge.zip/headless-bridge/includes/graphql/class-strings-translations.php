<?php
/**
 * Strings Translations - Translate strings via GraphQL
 */

defined('ABSPATH') || exit;

class Headless_Bridge_Strings_Translations {

    public static function init(): void {
        add_action('graphql_register_types', [self::class, 'register_types']);
    }

    public static function register_types(): void {
        register_graphql_field('RootQuery', 'translateString', [
            'type' => 'String',
            'description' => __('Translate a string using pll_translate_string() (Polylang)', 'headless-bridge'),
            'args' => [
                'string' => [
                    'type' => ['non_null' => 'String'],
                ],
                'language' => [
                    'type' => ['non_null' => 'LanguageCodeEnum'],
                ],
            ],
            'resolve' => function ($source, $args) {
                return pll_translate_string($args['string'], $args['language']);
            },
        ]);
    }
}
