<?php
/**
 * GraphQL Helpers for Polylang integration
 */

defined('ABSPATH') || exit;

class Headless_Bridge_GraphQL_Helpers {

    /**
     * Check if fields use slug-based data (code, slug, id)
     */
    public static function uses_slug_based_field(array $fields): bool {
        return isset($fields['code']) || isset($fields['slug']) || isset($fields['id']);
    }

    /**
     * Map 'language' or 'languages' query args to Polylang's 'lang' arg
     */
    public static function map_language_to_query_args(array $query_args, array $where_args): array {
        $lang = '';

        if (
            isset($where_args['languages']) &&
            is_array($where_args['languages']) &&
            !empty($where_args['languages'])
        ) {
            $langs = $where_args['languages'];
            $lang = implode(',', $langs);
        } elseif (isset($where_args['language'])) {
            $lang = $where_args['language'];

            if ('all' === $lang) {
                // Show all languages by default
                return $query_args;
            }

            if ('default' === $lang) {
                $lang = pll_default_language('slug');
            }
        } else {
            return $query_args;
        }

        $query_args['lang'] = $lang;

        return $query_args;
    }
}
