<?php
/**
 * GraphQL Menu Item - Polylang menu integration
 */

defined('ABSPATH') || exit;

class Headless_Bridge_GraphQL_Menu_Item {

    public static function init(): void {
        self::create_nav_menu_locations();

        add_action('graphql_register_types', [self::class, 'register_types']);
        add_filter('graphql_menu_item_connection_args', [self::class, 'filter_connection_args'], 10, 2);
    }

    public static function filter_connection_args(array $args, $unfiltered): array {
        if (!isset($args['where']['location'])) {
            return $args;
        }

        $lang = $args['where']['language'] ?? null;
        if (!$lang) {
            return $args;
        }

        // Only needed for non-default language
        if (pll_default_language('slug') === $lang) {
            return $args;
        }

        // Ex. TOP_MENU -> TOP_MENU___fi
        $args['where']['location'] .= '___' . $lang;

        return $args;
    }

    /**
     * Nav menu locations are created on admin_init with PLL_Admin but GraphQL
     * requests do not call it, so we must manually trigger it
     */
    private static function create_nav_menu_locations(): void {
        add_action('wp_loaded', function () {
            global $polylang;

            if (
                property_exists($polylang, 'nav_menu') &&
                $polylang->nav_menu
            ) {
                $polylang->nav_menu->create_nav_menu_locations();
            }
        }, 50);
    }

    public static function register_types(): void {
        register_graphql_fields('RootQueryToMenuItemConnectionWhereArgs', [
            'language' => [
                'type' => 'LanguageCodeFilterEnum',
                'description' => __('Filter menu items by language', 'headless-bridge'),
            ],
        ]);
    }
}
