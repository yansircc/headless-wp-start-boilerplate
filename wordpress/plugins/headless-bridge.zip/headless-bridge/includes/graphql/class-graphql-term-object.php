<?php
/**
 * GraphQL Term Object - Add Polylang fields to taxonomies
 */

defined('ABSPATH') || exit;

use GraphQLRelay\Relay;

class Headless_Bridge_GraphQL_Term_Object {

    public static function init(): void {
        add_action('graphql_register_types', [self::class, 'register_types']);
        add_filter(
            'graphql_map_input_fields_to_get_terms',
            ['Headless_Bridge_GraphQL_Helpers', 'map_language_to_query_args'],
            10,
            2
        );
        add_filter('graphql_term_object_insert_term_args', [self::class, 'filter_insert_term_args'], 10, 2);
    }

    public static function filter_insert_term_args(array $insert_args, array $input): array {
        if (isset($input['language'])) {
            $insert_args['language'] = $input['language'];
        }
        return $insert_args;
    }

    public static function register_types(): void {
        foreach (WPGraphQL::get_allowed_taxonomies() as $taxonomy) {
            self::add_taxonomy_fields(get_taxonomy($taxonomy));
        }
    }

    private static function add_taxonomy_fields(WP_Taxonomy $taxonomy): void {
        if (!pll_is_translated_taxonomy($taxonomy->name)) {
            return;
        }

        $type = ucfirst($taxonomy->graphql_single_name);

        // Connection where args
        register_graphql_fields("RootQueryTo{$type}ConnectionWhereArgs", [
            'language' => [
                'type' => 'LanguageCodeFilterEnum',
                'description' => sprintf(__('Filter %s by language code (Polylang)', 'headless-bridge'), $type),
            ],
            'languages' => [
                'type' => ['list_of' => ['non_null' => 'LanguageCodeEnum']],
                'description' => sprintf(__('Filter %s by one or more languages (Polylang)', 'headless-bridge'), $type),
            ],
        ]);

        // Mutation inputs
        register_graphql_fields("Create{$type}Input", [
            'language' => ['type' => 'LanguageCodeEnum'],
        ]);
        register_graphql_fields("Update{$type}Input", [
            'language' => ['type' => 'LanguageCodeEnum'],
        ]);

        // Handle language for term inserts
        add_action("graphql_insert_{$taxonomy->name}", function (int $term_id, array $args) {
            if (isset($args['language'])) {
                pll_set_term_language($term_id, $args['language']);
            } else {
                pll_set_term_language($term_id, pll_default_language());
            }
        }, 10, 2);

        // Handle language for term updates
        add_action("graphql_update_{$taxonomy->name}", function (int $term_id, array $args) {
            if (isset($args['language'])) {
                pll_set_term_language($term_id, $args['language']);
            }
        }, 10, 2);

        // Language field
        register_graphql_field($type, 'language', [
            'type' => 'Language',
            'description' => __('Term language (Polylang)', 'headless-bridge'),
            'resolve' => function (WPGraphQL\Model\Term $term, $args, $context, $info) {
                $fields = $info->getFieldSelection();
                $language = [];

                if (Headless_Bridge_GraphQL_Helpers::uses_slug_based_field($fields)) {
                    $language['code'] = pll_get_term_language($term->term_id, 'slug');
                    $language['slug'] = $language['code'];
                    $language['id'] = Relay::toGlobalId('Language', $language['code']);
                }

                if (isset($fields['name'])) {
                    $language['name'] = pll_get_term_language($term->term_id, 'name');
                }

                if (isset($fields['locale'])) {
                    $language['locale'] = pll_get_term_language($term->term_id, 'locale');
                }

                return $language;
            },
        ]);

        // Translations field
        register_graphql_field($type, 'translations', [
            'type' => ['list_of' => $type],
            'description' => __('List all translated versions of this term', 'headless-bridge'),
            'resolve' => function (WPGraphQL\Model\Term $term) {
                $terms = [];

                foreach (pll_get_term_translations($term->term_id) as $lang => $term_id) {
                    if ($term_id === $term->term_id) {
                        continue;
                    }

                    $translation = get_term($term_id);
                    if (!$translation || is_wp_error($translation)) {
                        continue;
                    }

                    $terms[] = new WPGraphQL\Model\Term($translation);
                }

                return $terms;
            },
        ]);

        // Translation field (get specific)
        register_graphql_field($type, 'translation', [
            'type' => $type,
            'description' => __('Get specific translation version of this term', 'headless-bridge'),
            'args' => [
                'language' => ['type' => ['non_null' => 'LanguageCodeEnum']],
            ],
            'resolve' => function (WPGraphQL\Model\Term $term, array $args) {
                $translations = pll_get_term_translations($term->term_id);
                $term_id = $translations[$args['language']] ?? null;

                if (!$term_id) {
                    return null;
                }

                return new WPGraphQL\Model\Term(get_term($term_id));
            },
        ]);
    }
}
