<?php
/**
 * GraphQL Post Object - Add Polylang fields to post types
 */

defined('ABSPATH') || exit;

use GraphQLRelay\Relay;

class Headless_Bridge_GraphQL_Post_Object {

    public static function init(): void {
        add_action('graphql_register_types', [self::class, 'register_types']);
        add_action(
            'graphql_post_object_mutation_update_additional_data',
            [self::class, 'handle_mutation'],
            10,
            4
        );
        add_filter(
            'graphql_map_input_fields_to_wp_query',
            ['Headless_Bridge_GraphQL_Helpers', 'map_language_to_query_args'],
            10,
            2
        );
        add_action('graphql_resolve_field', [self::class, 'check_translated_front_page'], 10, 8);
    }

    /**
     * Handle 'language' in post object create & update mutations
     */
    public static function handle_mutation(
        int $post_id,
        array $input,
        WP_Post_Type $post_type_object,
        string $mutation_name
    ): void {
        $is_create = substr($mutation_name, 0, 6) === 'create';

        if (isset($input['language'])) {
            pll_set_post_language($post_id, $input['language']);
        } elseif ($is_create) {
            $default_lang = pll_default_language();
            pll_set_post_language($post_id, $default_lang);
        }
    }

    public static function register_types(): void {
        // Add language filter to ContentNode connection
        register_graphql_fields('RootQueryToContentNodeConnectionWhereArgs', [
            'language' => [
                'type' => 'LanguageCodeFilterEnum',
                'description' => __('Filter content nodes by language code (Polylang)', 'headless-bridge'),
            ],
            'languages' => [
                'type' => ['list_of' => ['non_null' => 'LanguageCodeEnum']],
                'description' => __('Filter content nodes by one or more languages (Polylang)', 'headless-bridge'),
            ],
        ]);

        foreach (WPGraphQL::get_allowed_post_types() as $post_type) {
            self::add_post_type_fields(get_post_type_object($post_type));
        }
    }

    private static function add_post_type_fields(WP_Post_Type $post_type_object): void {
        if (!pll_is_translated_post_type($post_type_object->name)) {
            return;
        }

        $type = ucfirst($post_type_object->graphql_single_name);

        // Connection where args
        register_graphql_fields("RootQueryTo{$type}ConnectionWhereArgs", [
            'language' => [
                'type' => 'LanguageCodeFilterEnum',
                'description' => sprintf(__('Filter %s by language code (Polylang)', 'headless-bridge'), $type),
            ],
            'languages' => [
                'type' => ['list_of' => ['non_null' => 'LanguageCodeEnum']],
                'description' => sprintf(__('Filter %s by one or more languages (Polylang)', 'headless-bridge'), $type),
            ],
        ]);

        // Mutation inputs
        register_graphql_fields("Create{$type}Input", [
            'language' => ['type' => 'LanguageCodeEnum'],
        ]);

        register_graphql_fields("Update{$type}Input", [
            'language' => ['type' => 'LanguageCodeEnum'],
        ]);

        // Language field
        register_graphql_field($post_type_object->graphql_single_name, 'language', [
            'type' => 'Language',
            'description' => __('Post language (Polylang)', 'headless-bridge'),
            'resolve' => function (WPGraphQL\Model\Post $post, $args, $context, $info) {
                $fields = $info->getFieldSelection();
                $language = ['name' => null, 'slug' => null, 'code' => null];

                $post_id = $post->ID;

                // Preview posts need the original post id for language
                if ($post->isPreview) {
                    $post_id = wp_get_post_parent_id($post->ID);
                }

                $slug = pll_get_post_language($post_id, 'slug');
                if (!$slug) {
                    return null;
                }

                $language['code'] = $slug;
                $language['slug'] = $slug;
                $language['id'] = Relay::toGlobalId('Language', $slug);

                if (isset($fields['name'])) {
                    $language['name'] = pll_get_post_language($post_id, 'name');
                }

                if (isset($fields['locale'])) {
                    $language['locale'] = pll_get_post_language($post_id, 'locale');
                }

                return $language;
            },
        ]);

        // Translation field (get specific translation)
        register_graphql_field($post_type_object->graphql_single_name, 'translation', [
            'type' => $type,
            'description' => __('Get specific translation version of this post', 'headless-bridge'),
            'args' => [
                'language' => ['type' => ['non_null' => 'LanguageCodeEnum']],
            ],
            'resolve' => function (WPGraphQL\Model\Post $post, array $args) {
                $translations = pll_get_post_translations($post->ID);
                $post_id = $translations[$args['language']] ?? null;

                if (!$post_id) {
                    return null;
                }

                return new WPGraphQL\Model\Post(WP_Post::get_instance($post_id));
            },
        ]);

        // Translations field (list all translations)
        register_graphql_field($post_type_object->graphql_single_name, 'translations', [
            'type' => ['list_of' => $type],
            'description' => __('List all translated versions of this post', 'headless-bridge'),
            'resolve' => function (WPGraphQL\Model\Post $post) {
                $posts = [];

                if ($post->isPreview) {
                    $parent = wp_get_post_parent_id($post->ID);
                    $translations = pll_get_post_translations($parent);
                } else {
                    $translations = pll_get_post_translations($post->ID);
                }

                foreach ($translations as $lang => $post_id) {
                    $translation = WP_Post::get_instance($post_id);

                    if (!$translation || is_wp_error($translation)) {
                        continue;
                    }

                    if ($post->ID === $translation->ID) {
                        continue;
                    }

                    // Skip original when fetching preview
                    if ($post->isPreview && isset($parent) && $parent === $translation->ID) {
                        continue;
                    }

                    $model = new WPGraphQL\Model\Post($translation);

                    // Filter out private posts to avoid crashes
                    if ($model->is_private()) {
                        continue;
                    }

                    $posts[] = $model;
                }

                return $posts;
            },
        ]);
    }

    /**
     * Check if post is a translated front page
     */
    public static function check_translated_front_page(
        $result,
        $source,
        $args,
        $context,
        $info,
        $type_name,
        $field_key
    ) {
        if ('isFrontPage' !== $field_key) {
            return $result;
        }

        if (!($source instanceof WPGraphQL\Model\Post)) {
            return $result;
        }

        if ('page' !== get_option('show_on_front', 'posts')) {
            return $result;
        }

        $page_on_front = (int) get_option('page_on_front', 0);
        if (empty($page_on_front)) {
            return $result;
        }

        $translated_front_page = pll_get_post_translations($page_on_front);

        if (empty($translated_front_page)) {
            return false;
        }

        return in_array($source->ID, $translated_front_page, true);
    }
}
