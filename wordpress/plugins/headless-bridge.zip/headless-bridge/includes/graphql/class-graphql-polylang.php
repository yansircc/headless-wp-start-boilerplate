<?php
/**
 * GraphQL Polylang - Main loader
 *
 * Ported from: https://github.com/valu-digital/wp-graphql-polylang
 * Original Authors: Esa-Matti Suuronen, Valu Digital Oy
 * License: GPL-2.0+
 */

defined('ABSPATH') || exit;

class Headless_Bridge_GraphQL_Polylang {

    /**
     * Minimum Polylang version required (pll_context filter was added in 2.6)
     */
    private const MIN_POLYLANG_VERSION = '2.6';

    public static function init(): void {
        // Check Polylang version first
        if (!self::is_polylang_compatible()) {
            add_action('admin_notices', [self::class, 'action_admin_notices']);
            return;
        }

        add_filter('pll_model', [self::class, 'filter_pll_model']);
        add_filter('pll_context', [self::class, 'filter_pll_context']);
        add_filter('get_user_metadata', [self::class, 'filter_get_user_metadata'], 10, 4);
        add_action('graphql_init', [self::class, 'action_graphql_init']);
    }

    /**
     * Check if Polylang version is compatible
     */
    private static function is_polylang_compatible(): bool {
        return defined('POLYLANG_VERSION') && version_compare(POLYLANG_VERSION, self::MIN_POLYLANG_VERSION, '>=');
    }

    /**
     * Disable wp-admin language switcher on graphql context
     */
    public static function filter_get_user_metadata($data, int $object_id, string $meta_key, bool $single) {
        if ($meta_key !== 'pll_filter_content') {
            return $data;
        }

        if (!self::is_graphql_request()) {
            return $data;
        }

        return ['all'];
    }

    public static function action_graphql_init(): void {
        if (!self::is_graphql_request()) {
            return;
        }

        // Load sub-modules
        require_once __DIR__ . '/class-polylang-types.php';
        require_once __DIR__ . '/class-graphql-helpers.php';
        require_once __DIR__ . '/class-graphql-post-object.php';
        require_once __DIR__ . '/class-graphql-term-object.php';
        require_once __DIR__ . '/class-language-queries.php';
        require_once __DIR__ . '/class-graphql-menu-item.php';
        require_once __DIR__ . '/class-strings-translations.php';

        Headless_Bridge_Polylang_Types::init();
        Headless_Bridge_GraphQL_Post_Object::init();
        Headless_Bridge_GraphQL_Term_Object::init();
        Headless_Bridge_Language_Queries::init();
        Headless_Bridge_GraphQL_Menu_Item::init();
        Headless_Bridge_Strings_Translations::init();

        // ACF Options Pages support (optional)
        if (
            defined('BEA_ACF_OPTIONS_FOR_POLYLANG_VERSION') &&
            function_exists('acf_add_options_page')
        ) {
            require_once __DIR__ . '/class-graphql-options-pages.php';
            Headless_Bridge_GraphQL_Options_Pages::init();
        }
    }

    public static function filter_pll_model(string $class): string {
        if (self::is_graphql_request()) {
            return 'PLL_Admin_Model';
        }
        return $class;
    }

    public static function filter_pll_context(string $class): string {
        if (self::is_graphql_request()) {
            return 'PLL_Admin';
        }
        return $class;
    }

    public static function action_admin_notices(): void {
        if (!is_super_admin()) {
            return;
        }

        printf(
            '<div class="notice notice-error"><p>%s</p></div>',
            sprintf(
                esc_html__('Headless Bridge: Polylang %s or higher is required. You have %s.', 'headless-bridge'),
                self::MIN_POLYLANG_VERSION,
                defined('POLYLANG_VERSION') ? POLYLANG_VERSION : 'unknown'
            )
        );
    }

    public static function is_graphql_request(): bool {
        // Detect WPGraphQL activation
        if (!class_exists('WPGraphQL')) {
            return false;
        }

        if (!defined('POLYLANG_VERSION')) {
            return false;
        }

        if (defined('GRAPHQL_POLYLANG_TESTS')) {
            return true;
        }

        return function_exists('is_graphql_http_request') && is_graphql_http_request();
    }
}
