<?php
/**
 * GraphQL Options Pages - ACF Options For Polylang support
 *
 * Requires: "ACF Options For Polylang" plugin (bea/acf-options-for-polylang)
 * https://github.com/BeAPI/acf-options-for-polylang
 */

defined('ABSPATH') || exit;

use GraphQL\Type\Definition\ResolveInfo;

class Headless_Bridge_GraphQL_Options_Pages {

    /**
     * Mapping of used options page root queries to their selected languages
     */
    private static array $root_query_locale_mapping = [];

    /**
     * Language of the currently resolving options page field
     */
    private static ?string $current_language = null;

    public static function init(): void {
        add_filter('graphql_RootQuery_fields', [self::class, 'add_language_args'], 50);
        add_action('graphql_before_resolve_field', [self::class, 'before_resolve_field'], 10, 9);
        add_action('graphql_after_resolve_field', [self::class, 'after_resolve_field'], 10, 9);
        add_filter('acf/validate_post_id', [self::class, 'add_translation_suffix'], 99);
        add_filter('graphql_acf_get_root_id', [self::class, 'add_translation_suffix'], 99);
    }

    /**
     * Add language arg to all options page root queries
     */
    public static function add_language_args(array $fields): array {
        foreach (self::get_options_page_root_queries() as $root_query) {
            if (!isset($fields[$root_query])) {
                continue;
            }

            $fields[$root_query]['args'] = [
                'language' => [
                    'type' => 'LanguageCodeFilterEnum',
                    'description' => __('Filter by language code (Polylang)', 'headless-bridge'),
                ],
            ];
        }

        return $fields;
    }

    public static function before_resolve_field(
        $source,
        $args,
        $context,
        ResolveInfo $info,
        $field_resolver,
        $type_name,
        $field_key,
        $field
    ): void {
        // Record what languages are used by options page root queries
        if (isset($args['language']) && self::is_options_page_root_query($info)) {
            $model = PLL()->model;
            $lang = $model->get_language($args['language'])->locale ?? null;

            if ($lang) {
                self::$root_query_locale_mapping[$info->path[0]] = $lang;
            }
        }

        // If resolving field under options page root query, set current language
        if (self::is_options_page($source)) {
            $root_query = $info->path[0];
            $lang = self::$root_query_locale_mapping[$root_query] ?? null;
            if ($lang) {
                self::$current_language = $lang;
            }
        }
    }

    public static function after_resolve_field(
        $source,
        $args,
        $context,
        ResolveInfo $info,
        $field_resolver,
        $type_name,
        $field_key,
        $field
    ): void {
        // Clear current language after field resolution
        if (self::is_options_page($source)) {
            self::$current_language = null;
        }
    }

    public static function add_translation_suffix($id) {
        if (!self::$current_language) {
            return $id;
        }

        // Only add suffix once to "options" wp option
        if ($id !== 'options') {
            return $id;
        }

        return $id . '_' . self::$current_language;
    }

    private static function is_options_page($source): bool {
        if (!is_array($source)) {
            return false;
        }

        return ($source['type'] ?? null) === 'options_page';
    }

    private static function is_options_page_root_query(ResolveInfo $info): bool {
        if (count($info->path) !== 1) {
            return false;
        }

        return in_array($info->fieldName, self::get_options_page_root_queries(), true);
    }

    /**
     * Get array of options page root query names
     */
    private static function get_options_page_root_queries(): array {
        $graphql_options_pages = acf_get_options_pages();

        if (empty($graphql_options_pages) || !is_array($graphql_options_pages)) {
            return [];
        }

        $queries = [];

        foreach ($graphql_options_pages as $options_page_key => $options_page) {
            if (empty($options_page['show_in_graphql'])) {
                continue;
            }

            if (empty($options_page['graphql_field_name'])) {
                error_log("Warning(headless-bridge): ACF Options Page '{$options_page_key}' has no 'graphql_field_name'");
                continue;
            }

            $queries[] = $options_page['graphql_field_name'];
        }

        return $queries;
    }
}
