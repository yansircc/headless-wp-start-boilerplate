<?php
/**
 * ACF Sync - REST API for syncing ACF configurations
 */

defined('ABSPATH') || exit;

class Headless_Bridge_ACF_Sync {
    public static function init(): void {
        add_action('rest_api_init', [self::class, 'register_routes']);
    }

    public static function register_routes(): void {
        register_rest_route('headless-bridge/v1', '/push', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'handle_push'],
            'permission_callback' => [self::class, 'check_permission'],
        ]);

        register_rest_route('headless-bridge/v1', '/pull', [
            'methods'             => 'GET',
            'callback'            => [self::class, 'handle_pull'],
            'permission_callback' => [self::class, 'check_permission'],
        ]);

        register_rest_route('headless-bridge/v1', '/status', [
            'methods'             => 'GET',
            'callback'            => [self::class, 'handle_status'],
            'permission_callback' => [self::class, 'check_permission'],
        ]);
    }

    public static function check_permission(): bool {
        $api_key = $_SERVER['HTTP_X_HEADLESS_BRIDGE_KEY'] ?? $_SERVER['HTTP_X_ACF_SYNC_KEY'] ?? '';
        $valid_key = get_option('headless_bridge_api_key', 'dev-key-123');
        return $api_key === $valid_key;
    }

    public static function handle_push(WP_REST_Request $request): WP_REST_Response {
        $data = $request->get_json_params();

        if (empty($data['files']) || !is_array($data['files'])) {
            return new WP_REST_Response([
                'success' => false,
                'error'   => 'No files provided',
            ], 400);
        }

        $acf_json_path = WP_CONTENT_DIR . '/acf-json/';

        if (!file_exists($acf_json_path)) {
            wp_mkdir_p($acf_json_path);
        }

        $synced = [];
        $errors = [];

        foreach ($data['files'] as $file) {
            if (empty($file['filename']) || empty($file['content'])) {
                $errors[] = 'Invalid file structure';
                continue;
            }

            $filename = sanitize_file_name($file['filename']);
            $filepath = $acf_json_path . $filename;
            $content  = $file['content'];

            $json = json_encode($content, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            if (file_put_contents($filepath, $json) === false) {
                $errors[] = "Failed to write: {$filename}";
                continue;
            }

            $key = $content['key'] ?? '';

            try {
                $result = self::import_acf_content($filename, $content, $key);
                $synced[] = $result;
            } catch (Exception $e) {
                $errors[] = "Error importing {$filename}: " . $e->getMessage();
            }
        }

        return new WP_REST_Response([
            'success' => empty($errors),
            'synced'  => $synced,
            'errors'  => $errors,
        ]);
    }

    private static function import_acf_content(string $filename, array $content, string $key): array {
        if (strpos($filename, 'group_') === 0) {
            return self::import_field_group($content, $key, $filename);
        }

        if (strpos($filename, 'post-type_') === 0) {
            return self::import_post_type($content, $key, $filename);
        }

        if (strpos($filename, 'taxonomy_') === 0) {
            return self::import_taxonomy($content, $key, $filename);
        }

        return ['type' => 'unknown', 'key' => $key, 'filename' => $filename];
    }

    private static function import_field_group(array $content, string $key, string $filename): array {
        if (!function_exists('acf_import_field_group')) {
            return ['type' => 'field_group', 'key' => $key, 'filename' => $filename, 'note' => 'JSON saved, manual sync needed'];
        }

        if (function_exists('acf_get_field_group') && !empty($key)) {
            $existing = acf_get_field_group($key);
            if ($existing && !empty($existing['ID'])) {
                $content['ID'] = $existing['ID'];
            }
        }
        acf_import_field_group($content);
        return ['type' => 'field_group', 'key' => $key, 'filename' => $filename];
    }

    private static function import_post_type(array $content, string $key, string $filename): array {
        if (!function_exists('acf_import_post_type')) {
            return ['type' => 'post_type', 'key' => $key, 'filename' => $filename, 'note' => 'JSON saved, ACF PRO required'];
        }

        if (function_exists('acf_get_post_type') && !empty($key)) {
            $existing = acf_get_post_type($key);
            if ($existing && !empty($existing['ID'])) {
                $content['ID'] = $existing['ID'];
            }
        }
        acf_import_post_type($content);
        return ['type' => 'post_type', 'key' => $key, 'filename' => $filename];
    }

    private static function import_taxonomy(array $content, string $key, string $filename): array {
        if (!function_exists('acf_import_taxonomy')) {
            return ['type' => 'taxonomy', 'key' => $key, 'filename' => $filename, 'note' => 'JSON saved, ACF PRO required'];
        }

        if (function_exists('acf_get_taxonomy') && !empty($key)) {
            $existing = acf_get_taxonomy($key);
            if ($existing && !empty($existing['ID'])) {
                $content['ID'] = $existing['ID'];
            }
        }
        acf_import_taxonomy($content);
        return ['type' => 'taxonomy', 'key' => $key, 'filename' => $filename];
    }

    public static function handle_pull(): WP_REST_Response {
        $acf_json_path = WP_CONTENT_DIR . '/acf-json/';
        $files = [];

        if (!file_exists($acf_json_path)) {
            return new WP_REST_Response([
                'success' => true,
                'files'   => [],
                'message' => 'No acf-json directory found',
            ]);
        }

        foreach (glob($acf_json_path . '*.json') as $filepath) {
            $content = file_get_contents($filepath);
            $decoded = json_decode($content, true);

            if ($decoded === null) {
                continue;
            }

            $filename = basename($filepath);
            $type = 'unknown';
            if (strpos($filename, 'group_') === 0) {
                $type = 'field_group';
            } elseif (strpos($filename, 'post-type_') === 0) {
                $type = 'post_type';
            } elseif (strpos($filename, 'taxonomy_') === 0) {
                $type = 'taxonomy';
            }

            $files[] = [
                'filename' => $filename,
                'type'     => $type,
                'content'  => $decoded,
            ];
        }

        return new WP_REST_Response([
            'success' => true,
            'files'   => $files,
        ]);
    }

    public static function handle_status(): WP_REST_Response {
        $acf_json_path = WP_CONTENT_DIR . '/acf-json/';

        return new WP_REST_Response([
            'success'    => true,
            'version'    => HEADLESS_BRIDGE_VERSION,
            'acf_active' => function_exists('acf'),
            'acf_pro'    => function_exists('acf_pro'),
            'json_path'  => $acf_json_path,
            'writable'   => is_writable($acf_json_path),
            'file_count' => count(glob($acf_json_path . '*.json')),
            'webhook'    => [
                'enabled' => (bool) get_option('headless_bridge_webhook_enabled', false),
                'url'     => get_option('headless_bridge_webhook_url', ''),
            ],
            'kv' => [
                'enabled'   => (bool) get_option('headless_bridge_kv_enabled', false),
                'connected' => Headless_Bridge_Cloudflare_KV::test_connection()['success'] ?? false,
            ],
        ]);
    }
}
