<?php
/**
 * Admin - Settings page for Headless Bridge
 */

defined('ABSPATH') || exit;

class Headless_Bridge_Admin {
    public static function init(): void {
        add_action('admin_menu', [self::class, 'add_menu']);
        add_action('admin_enqueue_scripts', [self::class, 'enqueue_scripts']);
        add_action('wp_ajax_headless_bridge_test_webhook', [self::class, 'ajax_test_webhook']);
        add_action('wp_ajax_headless_bridge_full_sync', [self::class, 'ajax_full_sync']);
    }

    public static function add_menu(): void {
        add_options_page(
            'Headless Bridge',
            'Headless Bridge',
            'manage_options',
            'headless-bridge',
            [self::class, 'render_page']
        );
    }

    public static function enqueue_scripts($hook): void {
        if ($hook !== 'settings_page_headless-bridge') {
            return;
        }

        wp_enqueue_script(
            'headless-bridge-admin',
            HEADLESS_BRIDGE_URL . 'assets/admin.js',
            ['jquery'],
            HEADLESS_BRIDGE_VERSION,
            true
        );

        wp_localize_script('headless-bridge-admin', 'headlessBridge', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('headless_bridge_admin'),
        ]);
    }

    public static function render_page(): void {
        self::handle_form_submission();

        $api_key = get_option('headless_bridge_api_key', 'dev-key-123');
        $webhook_enabled = get_option('headless_bridge_webhook_enabled', false);
        $webhook_url = get_option('headless_bridge_webhook_url', '');
        $webhook_secret = get_option('headless_bridge_webhook_secret', '');
        $webhook_post_types = get_option('headless_bridge_webhook_post_types', '');
        $acf_json_path = WP_CONTENT_DIR . '/acf-json/';
        $locales = self::get_locales();
        ?>
        <style>
            .hb-wrap { max-width: 900px; margin: 20px 0; }
            .hb-header { display: flex; align-items: center; gap: 12px; margin-bottom: 24px; }
            .hb-header h1 { margin: 0; font-size: 28px; font-weight: 600; }
            .hb-version { background: #f0f0f1; padding: 4px 10px; border-radius: 4px; font-size: 12px; color: #50575e; }

            .hb-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
            @media (max-width: 960px) { .hb-grid { grid-template-columns: 1fr; } }

            .hb-card { background: #fff; border: 1px solid #c3c4c7; border-radius: 8px; padding: 20px; }
            .hb-card-full { grid-column: 1 / -1; }
            .hb-card h2 { margin: 0 0 16px 0; font-size: 16px; font-weight: 600; display: flex; align-items: center; gap: 8px; }
            .hb-card h2 .dashicons { color: #2271b1; font-size: 20px; width: 20px; height: 20px; }
            .hb-card p.desc { color: #646970; margin: -8px 0 16px 0; font-size: 13px; }

            .hb-field { margin-bottom: 16px; }
            .hb-field:last-child { margin-bottom: 0; }
            .hb-field label { display: block; font-weight: 500; margin-bottom: 6px; font-size: 13px; }
            .hb-field input[type="text"],
            .hb-field input[type="url"],
            .hb-field input[type="password"] { width: 100%; padding: 8px 12px; border: 1px solid #8c8f94; border-radius: 4px; font-size: 14px; }
            .hb-field input:focus { border-color: #2271b1; box-shadow: 0 0 0 1px #2271b1; outline: none; }
            .hb-field .hint { color: #646970; font-size: 12px; margin-top: 4px; }

            .hb-checkbox { display: flex; align-items: center; gap: 8px; }
            .hb-checkbox input { margin: 0; }

            .hb-status-grid { display: grid; gap: 8px; }
            .hb-status-row { display: flex; justify-content: space-between; align-items: center; padding: 10px 12px; background: #f6f7f7; border-radius: 4px; font-size: 13px; }
            .hb-status-row span:first-child { color: #50575e; }
            .hb-badge { padding: 2px 8px; border-radius: 10px; font-size: 11px; font-weight: 600; text-transform: uppercase; }
            .hb-badge-green { background: #d4edda; color: #155724; }
            .hb-badge-red { background: #f8d7da; color: #721c24; }
            .hb-badge-gray { background: #e9ecef; color: #495057; }

            .hb-endpoints { background: #f6f7f7; border-radius: 4px; padding: 12px; font-size: 13px; }
            .hb-endpoints code { background: #fff; padding: 2px 6px; border-radius: 3px; font-size: 12px; }
            .hb-endpoints li { margin-bottom: 8px; display: flex; gap: 8px; align-items: center; }
            .hb-endpoints li:last-child { margin-bottom: 0; }
            .hb-method { font-size: 10px; font-weight: 700; padding: 2px 6px; border-radius: 3px; }
            .hb-method-post { background: #fef3cd; color: #856404; }
            .hb-method-get { background: #d1ecf1; color: #0c5460; }

            .hb-payload { background: #1d2327; color: #c3c4c7; padding: 16px; border-radius: 6px; font-family: monospace; font-size: 12px; line-height: 1.6; overflow-x: auto; }
            .hb-payload .key { color: #9cdcfe; }
            .hb-payload .string { color: #ce9178; }
            .hb-payload .number { color: #b5cea8; }

            .hb-actions { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 16px; }
            .hb-btn { display: inline-flex; align-items: center; gap: 6px; padding: 10px 16px; border-radius: 4px; font-size: 13px; font-weight: 500; cursor: pointer; border: none; transition: all 0.15s; }
            .hb-btn .dashicons { font-size: 16px; width: 16px; height: 16px; }
            .hb-btn-primary { background: #2271b1; color: #fff; }
            .hb-btn-primary:hover { background: #135e96; }
            .hb-btn-secondary { background: #f6f7f7; color: #2271b1; border: 1px solid #2271b1; }
            .hb-btn-secondary:hover { background: #f0f0f1; }
            .hb-btn-success { background: #00a32a; color: #fff; }
            .hb-btn-success:hover { background: #008a20; }
            .hb-btn:disabled { opacity: 0.6; cursor: not-allowed; }

            .hb-result { margin-top: 12px; padding: 12px; border-radius: 4px; font-size: 13px; display: none; }
            .hb-result.success { background: #d4edda; color: #155724; display: block; }
            .hb-result.error { background: #f8d7da; color: #721c24; display: block; }
            .hb-result.loading { background: #fff3cd; color: #856404; display: block; }

            .hb-sync-info { background: #e7f3ff; border: 1px solid #72aee6; border-radius: 4px; padding: 12px 16px; margin-bottom: 16px; font-size: 13px; color: #1d4ed8; }
            .hb-sync-info code { background: rgba(0,0,0,0.05); padding: 2px 6px; border-radius: 3px; }
        </style>

        <div class="hb-wrap">
            <div class="hb-header">
                <h1>Headless Bridge</h1>
                <span class="hb-version">v<?php echo esc_html(HEADLESS_BRIDGE_VERSION); ?></span>
            </div>

            <form method="post">
                <?php wp_nonce_field('headless_bridge_settings'); ?>

                <div class="hb-grid">
                    <!-- Status Card -->
                    <div class="hb-card">
                        <h2><span class="dashicons dashicons-info-outline"></span> Status</h2>
                        <div class="hb-status-grid">
                            <div class="hb-status-row">
                                <span>ACF Plugin</span>
                                <?php if (function_exists('acf')): ?>
                                    <span class="hb-badge hb-badge-green">Active</span>
                                <?php else: ?>
                                    <span class="hb-badge hb-badge-red">Not Found</span>
                                <?php endif; ?>
                            </div>
                            <div class="hb-status-row">
                                <span>Polylang</span>
                                <?php if (function_exists('pll_languages_list')): ?>
                                    <span class="hb-badge hb-badge-green">Active</span>
                                <?php else: ?>
                                    <span class="hb-badge hb-badge-gray">Not Found</span>
                                <?php endif; ?>
                            </div>
                            <div class="hb-status-row">
                                <span>Languages</span>
                                <span><strong><?php echo esc_html(implode(', ', $locales)); ?></strong></span>
                            </div>
                            <div class="hb-status-row">
                                <span>ACF JSON Files</span>
                                <span><strong><?php echo count(glob($acf_json_path . '*.json')); ?></strong></span>
                            </div>
                            <div class="hb-status-row">
                                <span>Webhook Post Types</span>
                                <span><strong><?php echo esc_html(implode(', ', Headless_Bridge_Webhook::get_webhook_post_types())); ?></strong></span>
                            </div>
                        </div>
                    </div>

                    <!-- ACF Sync Card -->
                    <div class="hb-card">
                        <h2><span class="dashicons dashicons-update"></span> ACF Sync API</h2>
                        <p class="desc">Sync ACF field configurations with frontend</p>

                        <div class="hb-field">
                            <label for="api_key">API Key</label>
                            <input type="text" id="api_key" name="api_key" value="<?php echo esc_attr($api_key); ?>">
                            <div class="hint">Used for authentication when syncing ACF configurations</div>
                        </div>

                        <ul class="hb-endpoints" style="margin-top:16px; list-style:none; padding-left:0;">
                            <li><span class="hb-method hb-method-post">POST</span> <code>/wp-json/headless-bridge/v1/push</code></li>
                            <li><span class="hb-method hb-method-get">GET</span> <code>/wp-json/headless-bridge/v1/pull</code></li>
                            <li><span class="hb-method hb-method-get">GET</span> <code>/wp-json/headless-bridge/v1/status</code></li>
                        </ul>
                    </div>

                    <!-- Webhook Card -->
                    <div class="hb-card hb-card-full">
                        <h2><span class="dashicons dashicons-megaphone"></span> Content Webhook</h2>
                        <p class="desc">Notify frontend when content changes. Frontend fetches fresh data and updates KV cache.</p>

                        <div class="hb-grid" style="margin: 0 -10px;">
                            <div style="padding: 0 10px;">
                                <div class="hb-field">
                                    <label class="hb-checkbox">
                                        <input type="checkbox" name="webhook_enabled" <?php checked($webhook_enabled); ?>>
                                        Enable webhook notifications
                                    </label>
                                </div>

                                <div class="hb-field">
                                    <label for="webhook_url">Webhook URL</label>
                                    <input type="url" id="webhook_url" name="webhook_url" value="<?php echo esc_attr($webhook_url); ?>" placeholder="https://your-site.com/api/webhook/revalidate">
                                </div>

                                <div class="hb-field">
                                    <label for="webhook_secret">Secret Key</label>
                                    <input type="password" id="webhook_secret" name="webhook_secret" value="<?php echo esc_attr($webhook_secret); ?>">
                                    <div class="hint">HMAC-SHA256 signature key for request verification</div>
                                </div>

                                <div class="hb-field">
                                    <label for="webhook_post_types">Additional Post Types</label>
                                    <input type="text" id="webhook_post_types" name="webhook_post_types" value="<?php echo esc_attr($webhook_post_types); ?>" placeholder="page, custom_type">
                                    <div class="hint">Default: post, product</div>
                                </div>
                            </div>

                            <div style="padding: 0 10px;">
                                <label style="display:block; font-weight:500; margin-bottom:6px; font-size:13px;">Payload Format</label>
                                <div class="hb-payload">{
  <span class="key">"action"</span>: <span class="string">"update"</span>,
  <span class="key">"post_type"</span>: <span class="string">"product"</span>,
  <span class="key">"post_id"</span>: <span class="number">123</span>,
  <span class="key">"slug"</span>: <span class="string">"example-post"</span>,
  <span class="key">"locale"</span>: <span class="string">"en"</span>,
  <span class="key">"timestamp"</span>: <span class="number">1703318400</span>
}</div>
                            </div>
                        </div>

                        <div class="hb-actions" style="margin-top: 20px; padding-top: 16px; border-top: 1px solid #e0e0e0;">
                            <button type="button" id="test-webhook" class="hb-btn hb-btn-secondary" <?php echo !$webhook_enabled ? 'disabled' : ''; ?>>
                                <span class="dashicons dashicons-controls-play"></span> Test Webhook
                            </button>
                        </div>
                        <div id="webhook-result" class="hb-result"></div>
                    </div>

                    <!-- Full Sync Card -->
                    <div class="hb-card hb-card-full">
                        <h2><span class="dashicons dashicons-cloud-upload"></span> Full KV Sync</h2>
                        <p class="desc">Sync all content to Cloudflare KV cache. Use this after initial setup or to rebuild the cache.</p>

                        <div class="hb-sync-info">
                            This will call <code>POST /api/kv/sync</code> on your frontend to sync all content for all languages (<?php echo esc_html(implode(', ', $locales)); ?>).
                        </div>

                        <div class="hb-actions">
                            <button type="button" id="full-sync" class="hb-btn hb-btn-success" <?php echo !$webhook_enabled ? 'disabled' : ''; ?>>
                                <span class="dashicons dashicons-update"></span> Trigger Full Sync
                            </button>
                        </div>
                        <div id="sync-result" class="hb-result"></div>
                    </div>
                </div>

                <div class="hb-actions">
                    <button type="submit" name="save" class="hb-btn hb-btn-primary">
                        <span class="dashicons dashicons-saved"></span> Save Settings
                    </button>
                </div>
            </form>
        </div>
        <?php
    }

    private static function handle_form_submission(): void {
        if (!isset($_POST['save'])) {
            return;
        }

        if (!check_admin_referer('headless_bridge_settings')) {
            return;
        }

        update_option('headless_bridge_api_key', sanitize_text_field($_POST['api_key'] ?? ''));
        update_option('headless_bridge_webhook_enabled', isset($_POST['webhook_enabled']));
        update_option('headless_bridge_webhook_url', esc_url_raw($_POST['webhook_url'] ?? ''));
        update_option('headless_bridge_webhook_secret', sanitize_text_field($_POST['webhook_secret'] ?? ''));
        update_option('headless_bridge_webhook_post_types', sanitize_text_field($_POST['webhook_post_types'] ?? ''));

        echo '<div class="notice notice-success is-dismissible"><p>Settings saved successfully!</p></div>';
    }

    public static function ajax_test_webhook(): void {
        check_ajax_referer('headless_bridge_admin', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permission denied']);
        }

        $result = Headless_Bridge_Webhook::send_webhook([
            'action' => 'test',
            'post_type' => 'test',
            'post_id' => 0,
            'slug' => 'test',
            'locale' => 'en',
        ]);

        if ($result['success']) {
            wp_send_json_success([
                'message' => 'Webhook sent successfully!',
                'response' => $result['response'] ?? null,
            ]);
        } else {
            wp_send_json_error([
                'message' => $result['error'] ?? 'Unknown error',
            ]);
        }
    }

    public static function ajax_full_sync(): void {
        check_ajax_referer('headless_bridge_admin', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permission denied']);
        }

        $webhook_url = get_option('headless_bridge_webhook_url', '');
        $webhook_secret = get_option('headless_bridge_webhook_secret', '');

        if (empty($webhook_url)) {
            wp_send_json_error(['message' => 'Webhook URL not configured']);
        }

        // Build the sync URL from webhook URL
        // /api/webhook/revalidate -> /api/kv/sync
        $sync_url = preg_replace('#/api/webhook/revalidate$#', '/api/kv/sync', $webhook_url);

        if ($sync_url === $webhook_url) {
            // Fallback: just replace the endpoint
            $parsed = parse_url($webhook_url);
            $sync_url = $parsed['scheme'] . '://' . $parsed['host'];
            if (!empty($parsed['port'])) {
                $sync_url .= ':' . $parsed['port'];
            }
            $sync_url .= '/api/kv/sync';
        }

        $response = wp_remote_post($sync_url, [
            'timeout' => 60,
            'headers' => [
                'Authorization' => 'Bearer ' . $webhook_secret,
                'Content-Type' => 'application/json',
            ],
        ]);

        if (is_wp_error($response)) {
            wp_send_json_error([
                'message' => 'Request failed: ' . $response->get_error_message(),
            ]);
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code === 200 && !empty($body['success'])) {
            wp_send_json_success([
                'message' => sprintf(
                    'Synced %d keys across %d locales',
                    $body['total'] ?? 0,
                    count($body['locales'] ?? [])
                ),
                'details' => $body,
            ]);
        } else {
            wp_send_json_error([
                'message' => $body['error'] ?? 'Sync failed (HTTP ' . $code . ')',
                'details' => $body,
            ]);
        }
    }

    private static function get_locales(): array {
        if (function_exists('pll_languages_list')) {
            return pll_languages_list(['fields' => 'slug']);
        }
        return ['en'];
    }
}
