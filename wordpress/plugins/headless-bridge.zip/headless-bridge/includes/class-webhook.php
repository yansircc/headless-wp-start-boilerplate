<?php
/**
 * Webhook - Send notifications to frontend on content changes
 * Frontend is responsible for fetching data and updating KV cache
 */

defined('ABSPATH') || exit;

class Headless_Bridge_Webhook {
    public static function init(): void {
        add_action('save_post', [self::class, 'on_save_post'], 10, 3);
        add_action('transition_post_status', [self::class, 'on_status_change'], 10, 3);
        add_action('wp_trash_post', [self::class, 'on_trash']);
        add_action('before_delete_post', [self::class, 'on_delete']);
        add_action('untrash_post', [self::class, 'on_untrash']);
    }

    public static function get_webhook_post_types(): array {
        $custom = get_option('headless_bridge_webhook_post_types', '');
        $defaults = ['post', 'product'];

        if (!empty($custom)) {
            $custom_types = array_map('trim', explode(',', $custom));
            return array_unique(array_merge($defaults, $custom_types));
        }

        return $defaults;
    }

    /**
     * Send webhook with detailed response (for AJAX/admin use)
     */
    public static function send_webhook(array $payload): array {
        $url = get_option('headless_bridge_webhook_url', '');
        $secret = get_option('headless_bridge_webhook_secret', '');

        if (empty($url)) {
            return ['success' => false, 'error' => 'Webhook URL not configured'];
        }

        $payload['timestamp'] = $payload['timestamp'] ?? time();
        $signature = hash_hmac('sha256', json_encode($payload), $secret);

        $response = wp_remote_post($url, [
            'timeout'  => 30,
            'blocking' => true,
            'headers'  => [
                'Content-Type'                => 'application/json',
                'X-Headless-Bridge-Signature' => $signature,
            ],
            'body' => json_encode($payload),
        ]);

        if (is_wp_error($response)) {
            return ['success' => false, 'error' => $response->get_error_message()];
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code >= 200 && $code < 300) {
            return ['success' => true, 'response' => $body];
        }

        return [
            'success' => false,
            'error' => $body['error'] ?? 'HTTP ' . $code,
            'response' => $body,
        ];
    }

    /**
     * Send webhook (simple boolean return for hooks)
     */
    public static function send(string $action, string $post_type, int $post_id, string $slug = ''): bool {
        $enabled = get_option('headless_bridge_webhook_enabled', false);
        if (!$enabled) {
            return false;
        }

        // Get post language if Polylang is active
        $locale = 'en';
        if (function_exists('pll_get_post_language')) {
            $locale = pll_get_post_language($post_id, 'slug') ?: 'en';
        }

        $result = self::send_webhook([
            'action'    => $action,
            'post_type' => $post_type,
            'post_id'   => $post_id,
            'slug'      => $slug,
            'locale'    => $locale,
        ]);

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log(sprintf(
                '[Headless Bridge] Webhook %s: %s %s #%d (%s) [%s]',
                $result['success'] ? 'sent' : 'failed',
                $action,
                $post_type,
                $post_id,
                $slug,
                $locale
            ));
        }

        return $result['success'];
    }

    public static function on_save_post(int $post_id, WP_Post $post, bool $update): void {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (wp_is_post_revision($post_id)) {
            return;
        }

        $webhook_types = self::get_webhook_post_types();
        if (!in_array($post->post_type, $webhook_types, true)) {
            return;
        }

        if ($post->post_status !== 'publish') {
            return;
        }

        $action = $update ? 'update' : 'create';
        self::send($action, $post->post_type, $post_id, $post->post_name);
    }

    public static function on_status_change(string $new_status, string $old_status, WP_Post $post): void {
        $webhook_types = self::get_webhook_post_types();
        if (!in_array($post->post_type, $webhook_types, true)) {
            return;
        }

        if ($old_status === 'publish' && $new_status !== 'publish') {
            self::send('unpublish', $post->post_type, $post->ID, $post->post_name);
        }
    }

    public static function on_trash(int $post_id): void {
        $post = get_post($post_id);
        if (!$post) {
            return;
        }

        $webhook_types = self::get_webhook_post_types();
        if (!in_array($post->post_type, $webhook_types, true)) {
            return;
        }

        self::send('trash', $post->post_type, $post_id, $post->post_name);
    }

    public static function on_delete(int $post_id): void {
        $post = get_post($post_id);
        if (!$post) {
            return;
        }

        $webhook_types = self::get_webhook_post_types();
        if (!in_array($post->post_type, $webhook_types, true)) {
            return;
        }

        self::send('delete', $post->post_type, $post_id, $post->post_name);
    }

    public static function on_untrash(int $post_id): void {
        $post = get_post($post_id);
        if (!$post) {
            return;
        }

        $webhook_types = self::get_webhook_post_types();
        if (!in_array($post->post_type, $webhook_types, true)) {
            return;
        }

        if ($post->post_status === 'publish') {
            self::send('restore', $post->post_type, $post_id, $post->post_name);
        }
    }
}
