<?php
/**
 * Polylang Slug - Allow same slug for multiple languages
 *
 * Ported from: https://github.com/grappler/polylang-slug
 * Original Author: Ulrich Pogson
 * License: GPL-2.0+
 */

defined('ABSPATH') || exit;

class Headless_Bridge_Polylang_Slug {

    public static function init(): void {
        // Check if Polylang exists & minimum version is correct
        if (!defined('POLYLANG_VERSION') || version_compare(POLYLANG_VERSION, '1.7', '<=')) {
            return;
        }

        add_filter('wp_unique_post_slug', [self::class, 'unique_slug_in_language'], 10, 6);
        add_filter('query', [self::class, 'filter_queries']);
        add_filter('posts_where', [self::class, 'posts_where_filter'], 10, 2);
        add_filter('posts_join', [self::class, 'posts_join_filter'], 10, 2);
    }

    /**
     * Checks if the slug is unique within language.
     */
    public static function unique_slug_in_language(
        string $slug,
        int $post_ID,
        string $post_status,
        string $post_type,
        int $post_parent,
        string $original_slug
    ): string {
        global $wpdb;

        // Return slug if it was not changed
        if ($original_slug === $slug) {
            return $slug;
        }

        // Get language of post
        $lang = pll_get_post_language($post_ID);
        $options = get_option('polylang');

        // Return slug if Polylang does not return post language or has incompatible redirect setting
        if (empty($lang) || 0 === $options['force_lang'] || !pll_is_translated_post_type($post_type)) {
            return $slug;
        }

        $join_clause = self::get_join_clause();
        $where_clause = self::get_where_clause($lang);

        if ('attachment' === $post_type) {
            // Attachment slugs must be unique across all types
            $check_sql = "SELECT post_name FROM {$wpdb->posts} {$join_clause} WHERE post_name = %s AND ID != %d {$where_clause} LIMIT 1";
            $post_name_check = $wpdb->get_var($wpdb->prepare($check_sql, $original_slug, $post_ID));
        } elseif (is_post_type_hierarchical($post_type)) {
            // Page slugs must be unique within their own trees
            $check_sql = "SELECT ID FROM {$wpdb->posts} {$join_clause} WHERE post_name = %s AND post_type IN ( %s, 'attachment' ) AND ID != %d AND post_parent = %d {$where_clause} LIMIT 1";
            $post_name_check = $wpdb->get_var($wpdb->prepare($check_sql, $original_slug, $post_type, $post_ID, $post_parent));
        } else {
            // Post slugs must be unique across all posts
            $check_sql = "SELECT post_name FROM {$wpdb->posts} {$join_clause} WHERE post_name = %s AND post_type = %s AND ID != %d {$where_clause} LIMIT 1";
            $post_name_check = $wpdb->get_var($wpdb->prepare($check_sql, $original_slug, $post_type, $post_ID));
        }

        if (!$post_name_check) {
            return $original_slug;
        }

        return $slug;
    }

    /**
     * Modify the sql query to include checks for the current language.
     */
    public static function filter_queries(string $query): string {
        global $wpdb;

        // Query for posts page, pages, attachments and hierarchical CPT
        $is_pages_sql = preg_match(
            "#SELECT ID, post_name, post_parent, post_type FROM {$wpdb->posts} .*#",
            self::standardize_query($query),
            $matches
        );

        if (!$is_pages_sql) {
            return $query;
        }

        if (!self::should_run()) {
            return $query;
        }

        $lang = pll_current_language();
        $join_clause = self::get_join_clause();
        $where_clause = self::get_where_clause($lang);

        preg_match(
            "#(SELECT .* (?=FROM))(FROM .* (?=WHERE))(?:(WHERE .*(?=ORDER))|(WHERE .*$))(.*)#",
            self::standardize_query($query),
            $matches
        );

        // Reindex array numerically
        $matches = array_values($matches);

        // SELECT, FROM, INNER JOIN, WHERE, WHERE CLAUSE (additional), ORDER BY (if included)
        $sql_query = $matches[1] . $matches[2] . $join_clause . $matches[3] . $where_clause . $matches[4];

        return apply_filters('headless_bridge_polylang_slug_sql_query', $sql_query, $matches, $join_clause, $where_clause);
    }

    /**
     * Extend the WHERE clause of the query.
     */
    public static function posts_where_filter(string $where, WP_Query $query): string {
        if (!self::should_run($query)) {
            return $where;
        }

        $lang = empty($query->query['lang']) ? pll_current_language() : $query->query['lang'];
        $where .= self::get_where_clause($lang);

        return $where;
    }

    /**
     * Extend the JOIN clause of the query.
     */
    public static function posts_join_filter(string $join, WP_Query $query): string {
        if (!self::should_run($query)) {
            return $join;
        }

        $join .= self::get_join_clause();

        return $join;
    }

    /**
     * Check if the query needs to be adapted.
     */
    private static function should_run($query = null): bool {
        $disable = apply_filters('headless_bridge_polylang_slug_disable', false, $query);

        if (is_admin() || is_feed() || !function_exists('pll_current_language') || $disable) {
            return false;
        }

        if ($query instanceof WP_Query) {
            $lang = empty($query->query['lang']) ? pll_current_language() : $query->query['lang'];
            $is_translated = !empty($query->query['post_type']) && !pll_is_translated_post_type($query->query['post_type']);

            if (empty($lang) || $is_translated) {
                return false;
            }
        }

        return true;
    }

    /**
     * Standardize the query for regex matching.
     */
    private static function standardize_query(string $query): string {
        $query = str_replace(
            ["\t", " \n", "\n", " \r", "\r", "   ", "  "],
            ['', ' ', ' ', ' ', ' ', ' ', ' '],
            $query
        );
        return trim($query);
    }

    /**
     * Get Polylang join clause.
     */
    private static function get_join_clause(): string {
        if (function_exists('PLL')) {
            return PLL()->model->post->join_clause();
        }

        if (isset($GLOBALS['polylang'])) {
            return $GLOBALS['polylang']->model->join_clause('post');
        }

        return '';
    }

    /**
     * Get Polylang where clause.
     */
    private static function get_where_clause(string $lang = ''): string {
        if (function_exists('PLL')) {
            return PLL()->model->post->where_clause($lang);
        }

        if (isset($GLOBALS['polylang'])) {
            return $GLOBALS['polylang']->model->where_clause($lang, 'post');
        }

        return '';
    }
}
