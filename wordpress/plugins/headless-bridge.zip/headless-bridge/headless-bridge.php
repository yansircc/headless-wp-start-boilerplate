<?php
/**
 * Plugin Name: Headless Bridge
 * Description: Bridge between WordPress and headless frontends - ACF sync + webhook notifications
 * Version: 0.0.5
 * Author: Headless Codegen
 * Requires PHP: 7.4
 */

defined('ABSPATH') || exit;

define('HEADLESS_BRIDGE_VERSION', '0.0.5');
define('HEADLESS_BRIDGE_PATH', plugin_dir_path(__FILE__));
define('HEADLESS_BRIDGE_URL', plugin_dir_url(__FILE__));

require_once HEADLESS_BRIDGE_PATH . 'includes/class-loader.php';

add_action('plugins_loaded', function () {
    Headless_Bridge_Loader::init();
});
