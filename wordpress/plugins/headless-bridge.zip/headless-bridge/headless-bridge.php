<?php
/**
 * Plugin Name: Headless Bridge
 * Description: Bridge between WordPress and headless frontends - ACF sync + content webhook notifications
 * Version: 2.0.0
 * Author: Headless Codegen
 */

defined('ABSPATH') || exit;

// ============================================================================
// CONSTANTS
// ============================================================================

define('HEADLESS_BRIDGE_VERSION', '2.0.0');

// ============================================================================
// REST API ROUTES
// ============================================================================

add_action('rest_api_init', function () {
    // POST /wp-json/headless-bridge/v1/push - Push ACF configurations
    register_rest_route('headless-bridge/v1', '/push', [
        'methods'             => 'POST',
        'callback'            => 'headless_bridge_push',
        'permission_callback' => 'headless_bridge_permission_check',
    ]);

    // GET /wp-json/headless-bridge/v1/pull - Pull ACF configurations
    register_rest_route('headless-bridge/v1', '/pull', [
        'methods'             => 'GET',
        'callback'            => 'headless_bridge_pull',
        'permission_callback' => 'headless_bridge_permission_check',
    ]);

    // GET /wp-json/headless-bridge/v1/status - Check status
    register_rest_route('headless-bridge/v1', '/status', [
        'methods'             => 'GET',
        'callback'            => 'headless_bridge_status',
        'permission_callback' => 'headless_bridge_permission_check',
    ]);
});

// ============================================================================
// PERMISSION CHECK
// ============================================================================

function headless_bridge_permission_check(): bool {
    $api_key = $_SERVER['HTTP_X_HEADLESS_BRIDGE_KEY'] ?? $_SERVER['HTTP_X_ACF_SYNC_KEY'] ?? '';
    $valid_key = get_option('headless_bridge_api_key', 'dev-key-123');
    return $api_key === $valid_key;
}

// ============================================================================
// ACF SYNC FUNCTIONS (preserved from original)
// ============================================================================

function headless_bridge_push(WP_REST_Request $request): WP_REST_Response {
    $data = $request->get_json_params();

    if (empty($data['files']) || !is_array($data['files'])) {
        return new WP_REST_Response([
            'success' => false,
            'error'   => 'No files provided',
        ], 400);
    }

    $acf_json_path = WP_CONTENT_DIR . '/acf-json/';

    if (!file_exists($acf_json_path)) {
        wp_mkdir_p($acf_json_path);
    }

    $synced = [];
    $errors = [];

    foreach ($data['files'] as $file) {
        if (empty($file['filename']) || empty($file['content'])) {
            $errors[] = 'Invalid file structure';
            continue;
        }

        $filename = sanitize_file_name($file['filename']);
        $filepath = $acf_json_path . $filename;
        $content  = $file['content'];

        $json = json_encode($content, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        if (file_put_contents($filepath, $json) === false) {
            $errors[] = "Failed to write: {$filename}";
            continue;
        }

        $key = $content['key'] ?? '';

        try {
            if (strpos($filename, 'group_') === 0) {
                if (function_exists('acf_import_field_group')) {
                    if (function_exists('acf_get_field_group') && !empty($key)) {
                        $existing = acf_get_field_group($key);
                        if ($existing && !empty($existing['ID'])) {
                            $content['ID'] = $existing['ID'];
                        }
                    }
                    acf_import_field_group($content);
                    $synced[] = ['type' => 'field_group', 'key' => $key, 'filename' => $filename];
                } else {
                    $synced[] = ['type' => 'field_group', 'key' => $key, 'filename' => $filename, 'note' => 'JSON saved, manual sync needed'];
                }
            } elseif (strpos($filename, 'post-type_') === 0) {
                if (function_exists('acf_import_post_type')) {
                    if (function_exists('acf_get_post_type') && !empty($key)) {
                        $existing = acf_get_post_type($key);
                        if ($existing && !empty($existing['ID'])) {
                            $content['ID'] = $existing['ID'];
                        }
                    }
                    acf_import_post_type($content);
                    $synced[] = ['type' => 'post_type', 'key' => $key, 'filename' => $filename];
                } else {
                    $synced[] = ['type' => 'post_type', 'key' => $key, 'filename' => $filename, 'note' => 'JSON saved, ACF PRO required'];
                }
            } elseif (strpos($filename, 'taxonomy_') === 0) {
                if (function_exists('acf_import_taxonomy')) {
                    if (function_exists('acf_get_taxonomy') && !empty($key)) {
                        $existing = acf_get_taxonomy($key);
                        if ($existing && !empty($existing['ID'])) {
                            $content['ID'] = $existing['ID'];
                        }
                    }
                    acf_import_taxonomy($content);
                    $synced[] = ['type' => 'taxonomy', 'key' => $key, 'filename' => $filename];
                } else {
                    $synced[] = ['type' => 'taxonomy', 'key' => $key, 'filename' => $filename, 'note' => 'JSON saved, ACF PRO required'];
                }
            } else {
                $synced[] = ['type' => 'unknown', 'key' => $key, 'filename' => $filename];
            }
        } catch (Exception $e) {
            $errors[] = "Error importing {$filename}: " . $e->getMessage();
        }
    }

    return new WP_REST_Response([
        'success' => empty($errors),
        'synced'  => $synced,
        'errors'  => $errors,
    ]);
}

function headless_bridge_pull(): WP_REST_Response {
    $acf_json_path = WP_CONTENT_DIR . '/acf-json/';
    $files = [];

    if (!file_exists($acf_json_path)) {
        return new WP_REST_Response([
            'success' => true,
            'files'   => [],
            'message' => 'No acf-json directory found',
        ]);
    }

    foreach (glob($acf_json_path . '*.json') as $filepath) {
        $content = file_get_contents($filepath);
        $decoded = json_decode($content, true);

        if ($decoded === null) {
            continue;
        }

        $filename = basename($filepath);
        $type = 'unknown';
        if (strpos($filename, 'group_') === 0) {
            $type = 'field_group';
        } elseif (strpos($filename, 'post-type_') === 0) {
            $type = 'post_type';
        } elseif (strpos($filename, 'taxonomy_') === 0) {
            $type = 'taxonomy';
        }

        $files[] = [
            'filename' => $filename,
            'type'     => $type,
            'content'  => $decoded,
        ];
    }

    return new WP_REST_Response([
        'success' => true,
        'files'   => $files,
    ]);
}

function headless_bridge_status(): WP_REST_Response {
    $acf_json_path = WP_CONTENT_DIR . '/acf-json/';

    return new WP_REST_Response([
        'success'    => true,
        'version'    => HEADLESS_BRIDGE_VERSION,
        'acf_active' => function_exists('acf'),
        'acf_pro'    => function_exists('acf_pro'),
        'json_path'  => $acf_json_path,
        'writable'   => is_writable($acf_json_path),
        'file_count' => count(glob($acf_json_path . '*.json')),
        'webhook'    => [
            'enabled' => (bool) get_option('headless_bridge_webhook_enabled', false),
            'url'     => get_option('headless_bridge_webhook_url', ''),
        ],
    ]);
}

// ============================================================================
// WEBHOOK FUNCTIONALITY
// ============================================================================

/**
 * Get post types that should trigger webhooks
 */
function headless_bridge_get_webhook_post_types(): array {
    $custom = get_option('headless_bridge_webhook_post_types', '');
    $defaults = ['post', 'product'];

    if (!empty($custom)) {
        $custom_types = array_map('trim', explode(',', $custom));
        return array_unique(array_merge($defaults, $custom_types));
    }

    return $defaults;
}

/**
 * Send webhook notification to frontend
 */
function headless_bridge_send_webhook(string $action, string $post_type, int $post_id, string $slug = ''): void {
    $enabled = get_option('headless_bridge_webhook_enabled', false);
    $url = get_option('headless_bridge_webhook_url', '');
    $secret = get_option('headless_bridge_webhook_secret', '');

    if (!$enabled || empty($url)) {
        return;
    }

    $payload = [
        'action'    => $action,      // create, update, delete, trash, restore
        'post_type' => $post_type,
        'post_id'   => $post_id,
        'slug'      => $slug,
        'timestamp' => time(),
    ];

    // Generate signature for verification
    $signature = hash_hmac('sha256', json_encode($payload), $secret);

    $response = wp_remote_post($url, [
        'timeout'   => 10,
        'blocking'  => false, // Non-blocking, don't wait for response
        'headers'   => [
            'Content-Type'              => 'application/json',
            'X-Headless-Bridge-Signature' => $signature,
        ],
        'body'      => json_encode($payload),
    ]);

    // Log webhook (optional, for debugging)
    if (defined('WP_DEBUG') && WP_DEBUG) {
        error_log(sprintf(
            '[Headless Bridge] Webhook sent: %s %s #%d (%s)',
            $action,
            $post_type,
            $post_id,
            $slug
        ));
    }
}

/**
 * Hook: Post saved (create or update)
 */
add_action('save_post', function (int $post_id, WP_Post $post, bool $update): void {
    // Skip autosaves and revisions
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (wp_is_post_revision($post_id)) {
        return;
    }

    // Check if this post type should trigger webhooks
    $webhook_types = headless_bridge_get_webhook_post_types();
    if (!in_array($post->post_type, $webhook_types, true)) {
        return;
    }

    // Only trigger for published posts
    if ($post->post_status !== 'publish') {
        return;
    }

    $action = $update ? 'update' : 'create';
    headless_bridge_send_webhook($action, $post->post_type, $post_id, $post->post_name);
}, 10, 3);

/**
 * Hook: Post status transition (for publish/unpublish detection)
 */
add_action('transition_post_status', function (string $new_status, string $old_status, WP_Post $post): void {
    $webhook_types = headless_bridge_get_webhook_post_types();
    if (!in_array($post->post_type, $webhook_types, true)) {
        return;
    }

    // Published -> Something else (unpublish)
    if ($old_status === 'publish' && $new_status !== 'publish') {
        headless_bridge_send_webhook('unpublish', $post->post_type, $post->ID, $post->post_name);
    }

    // Something else -> Published (first publish handled by save_post, but this catches scheduled posts)
    if ($old_status !== 'publish' && $new_status === 'publish') {
        // This will be handled by save_post hook
    }
}, 10, 3);

/**
 * Hook: Post trashed
 */
add_action('wp_trash_post', function (int $post_id): void {
    $post = get_post($post_id);
    if (!$post) {
        return;
    }

    $webhook_types = headless_bridge_get_webhook_post_types();
    if (!in_array($post->post_type, $webhook_types, true)) {
        return;
    }

    headless_bridge_send_webhook('trash', $post->post_type, $post_id, $post->post_name);
});

/**
 * Hook: Post deleted permanently
 */
add_action('before_delete_post', function (int $post_id): void {
    $post = get_post($post_id);
    if (!$post) {
        return;
    }

    $webhook_types = headless_bridge_get_webhook_post_types();
    if (!in_array($post->post_type, $webhook_types, true)) {
        return;
    }

    headless_bridge_send_webhook('delete', $post->post_type, $post_id, $post->post_name);
});

/**
 * Hook: Post restored from trash
 */
add_action('untrash_post', function (int $post_id): void {
    $post = get_post($post_id);
    if (!$post) {
        return;
    }

    $webhook_types = headless_bridge_get_webhook_post_types();
    if (!in_array($post->post_type, $webhook_types, true)) {
        return;
    }

    // Only send if post is published after restore
    if ($post->post_status === 'publish') {
        headless_bridge_send_webhook('restore', $post->post_type, $post_id, $post->post_name);
    }
});

// ============================================================================
// ADMIN SETTINGS PAGE
// ============================================================================

add_action('admin_menu', function () {
    add_options_page(
        'Headless Bridge',
        'Headless Bridge',
        'manage_options',
        'headless-bridge',
        'headless_bridge_settings_page'
    );
});

function headless_bridge_settings_page(): void {
    // Handle form submission
    if (isset($_POST['headless_bridge_save']) && check_admin_referer('headless_bridge_settings')) {
        update_option('headless_bridge_api_key', sanitize_text_field($_POST['headless_bridge_api_key'] ?? ''));
        update_option('headless_bridge_webhook_enabled', isset($_POST['headless_bridge_webhook_enabled']));
        update_option('headless_bridge_webhook_url', esc_url_raw($_POST['headless_bridge_webhook_url'] ?? ''));
        update_option('headless_bridge_webhook_secret', sanitize_text_field($_POST['headless_bridge_webhook_secret'] ?? ''));
        update_option('headless_bridge_webhook_post_types', sanitize_text_field($_POST['headless_bridge_webhook_post_types'] ?? ''));
        echo '<div class="notice notice-success"><p>Settings saved!</p></div>';
    }

    // Handle test webhook
    if (isset($_POST['headless_bridge_test_webhook']) && check_admin_referer('headless_bridge_settings')) {
        $url = get_option('headless_bridge_webhook_url', '');
        $secret = get_option('headless_bridge_webhook_secret', '');

        if (empty($url)) {
            echo '<div class="notice notice-error"><p>Please configure webhook URL first.</p></div>';
        } else {
            $payload = [
                'action'    => 'test',
                'post_type' => 'test',
                'post_id'   => 0,
                'slug'      => 'test-webhook',
                'timestamp' => time(),
            ];

            $signature = hash_hmac('sha256', json_encode($payload), $secret);

            $response = wp_remote_post($url, [
                'timeout' => 10,
                'headers' => [
                    'Content-Type'                => 'application/json',
                    'X-Headless-Bridge-Signature' => $signature,
                ],
                'body' => json_encode($payload),
            ]);

            if (is_wp_error($response)) {
                echo '<div class="notice notice-error"><p>Webhook test failed: ' . esc_html($response->get_error_message()) . '</p></div>';
            } else {
                $code = wp_remote_retrieve_response_code($response);
                if ($code >= 200 && $code < 300) {
                    echo '<div class="notice notice-success"><p>Webhook test successful! Response code: ' . esc_html($code) . '</p></div>';
                } else {
                    echo '<div class="notice notice-warning"><p>Webhook returned code: ' . esc_html($code) . '</p></div>';
                }
            }
        }
    }

    // Get current values
    $api_key = get_option('headless_bridge_api_key', 'dev-key-123');
    $webhook_enabled = get_option('headless_bridge_webhook_enabled', false);
    $webhook_url = get_option('headless_bridge_webhook_url', '');
    $webhook_secret = get_option('headless_bridge_webhook_secret', '');
    $webhook_post_types = get_option('headless_bridge_webhook_post_types', '');
    ?>
    <div class="wrap">
        <h1>Headless Bridge Settings</h1>
        <p>Version <?php echo esc_html(HEADLESS_BRIDGE_VERSION); ?> - Bridge between WordPress and headless frontends</p>

        <form method="post">
            <?php wp_nonce_field('headless_bridge_settings'); ?>

            <h2>ACF Sync API</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">API Key</th>
                    <td>
                        <input type="text" name="headless_bridge_api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text">
                        <p class="description">Used for authentication when syncing ACF configurations.</p>
                    </td>
                </tr>
            </table>

            <h2>Content Webhook</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">Enable Webhook</th>
                    <td>
                        <label>
                            <input type="checkbox" name="headless_bridge_webhook_enabled" <?php checked($webhook_enabled); ?>>
                            Send webhook notifications when content changes
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Webhook URL</th>
                    <td>
                        <input type="url" name="headless_bridge_webhook_url" value="<?php echo esc_attr($webhook_url); ?>" class="large-text" placeholder="https://your-frontend.com/api/webhook/revalidate">
                        <p class="description">Frontend endpoint that will receive webhook notifications.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Webhook Secret</th>
                    <td>
                        <input type="text" name="headless_bridge_webhook_secret" value="<?php echo esc_attr($webhook_secret); ?>" class="regular-text" placeholder="your-secret-key">
                        <p class="description">Shared secret for verifying webhook authenticity. Used to generate HMAC signature.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Additional Post Types</th>
                    <td>
                        <input type="text" name="headless_bridge_webhook_post_types" value="<?php echo esc_attr($webhook_post_types); ?>" class="regular-text" placeholder="page, custom_type">
                        <p class="description">Comma-separated list of additional post types. Default: <code>post, product</code></p>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <button type="submit" name="headless_bridge_save" class="button button-primary">Save Settings</button>
                <button type="submit" name="headless_bridge_test_webhook" class="button">Test Webhook</button>
            </p>
        </form>

        <hr>

        <h2>API Endpoints</h2>
        <table class="widefat" style="max-width: 800px;">
            <thead>
                <tr>
                    <th>Endpoint</th>
                    <th>Method</th>
                    <th>Description</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><code>/wp-json/headless-bridge/v1/push</code></td>
                    <td>POST</td>
                    <td>Push ACF configurations from frontend</td>
                </tr>
                <tr>
                    <td><code>/wp-json/headless-bridge/v1/pull</code></td>
                    <td>GET</td>
                    <td>Pull ACF configurations to frontend</td>
                </tr>
                <tr>
                    <td><code>/wp-json/headless-bridge/v1/status</code></td>
                    <td>GET</td>
                    <td>Check plugin status</td>
                </tr>
            </tbody>
        </table>

        <h3>Webhook Payload Example</h3>
        <pre style="background: #f1f1f1; padding: 15px; max-width: 600px; overflow: auto;">
{
    "action": "update",
    "post_type": "product",
    "post_id": 123,
    "slug": "example-product",
    "timestamp": 1703318400
}

Header: X-Headless-Bridge-Signature: &lt;HMAC-SHA256&gt;</pre>

        <h3>Verify Webhook Signature (Node.js)</h3>
        <pre style="background: #f1f1f1; padding: 15px; max-width: 600px; overflow: auto;">
import crypto from 'crypto';

function verifySignature(payload, signature, secret) {
    const expected = crypto
        .createHmac('sha256', secret)
        .update(JSON.stringify(payload))
        .digest('hex');
    return crypto.timingSafeEqual(
        Buffer.from(signature),
        Buffer.from(expected)
    );
}</pre>
    </div>
    <?php
}

// ============================================================================
// MIGRATION: Support old option names for backwards compatibility
// ============================================================================

add_action('admin_init', function () {
    // Migrate old API key option
    $old_key = get_option('acf_sync_api_key');
    if ($old_key && !get_option('headless_bridge_api_key')) {
        update_option('headless_bridge_api_key', $old_key);
        delete_option('acf_sync_api_key');
    }
});
