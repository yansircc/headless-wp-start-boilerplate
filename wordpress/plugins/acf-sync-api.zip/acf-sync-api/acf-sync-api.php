<?php
/**
 * Plugin Name: ACF Sync API
 * Description: REST API for syncing ACF configurations from frontend projects
 * Version: 1.0.0
 * Author: Headless Codegen
 */

defined('ABSPATH') || exit;

/**
 * Register REST API routes
 */
add_action('rest_api_init', function () {
    // POST /wp-json/acf-sync/v1/push - Push configurations
    register_rest_route('acf-sync/v1', '/push', [
        'methods'             => 'POST',
        'callback'            => 'acf_sync_push',
        'permission_callback' => 'acf_sync_permission_check',
    ]);

    // GET /wp-json/acf-sync/v1/pull - Pull configurations
    register_rest_route('acf-sync/v1', '/pull', [
        'methods'             => 'GET',
        'callback'            => 'acf_sync_pull',
        'permission_callback' => 'acf_sync_permission_check',
    ]);

    // GET /wp-json/acf-sync/v1/status - Check sync status
    register_rest_route('acf-sync/v1', '/status', [
        'methods'             => 'GET',
        'callback'            => 'acf_sync_status',
        'permission_callback' => 'acf_sync_permission_check',
    ]);
});

/**
 * Permission check - use API key for local development
 */
function acf_sync_permission_check(): bool {
    // Get API key from header
    $api_key = $_SERVER['HTTP_X_ACF_SYNC_KEY'] ?? '';

    // Default key for local development (change in production)
    $valid_key = get_option('acf_sync_api_key', 'dev-key-123');

    return $api_key === $valid_key;
}

/**
 * Push ACF configurations from frontend to WordPress
 */
function acf_sync_push(WP_REST_Request $request): WP_REST_Response {
    $data = $request->get_json_params();

    if (empty($data['files']) || !is_array($data['files'])) {
        return new WP_REST_Response([
            'success' => false,
            'error'   => 'No files provided',
        ], 400);
    }

    $acf_json_path = WP_CONTENT_DIR . '/acf-json/';

    // Ensure directory exists
    if (!file_exists($acf_json_path)) {
        wp_mkdir_p($acf_json_path);
    }

    $synced = [];
    $errors = [];

    foreach ($data['files'] as $file) {
        if (empty($file['filename']) || empty($file['content'])) {
            $errors[] = 'Invalid file structure';
            continue;
        }

        $filename = sanitize_file_name($file['filename']);
        $filepath = $acf_json_path . $filename;
        $content  = $file['content'];

        // Write JSON file
        $json = json_encode($content, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        if (file_put_contents($filepath, $json) === false) {
            $errors[] = "Failed to write: {$filename}";
            continue;
        }

        // Import to database based on file type
        $key = $content['key'] ?? '';

        try {
            if (strpos($filename, 'group_') === 0) {
                // Field Group
                if (function_exists('acf_import_field_group')) {
                    // Check if field group already exists by key
                    if (function_exists('acf_get_field_group') && !empty($key)) {
                        $existing = acf_get_field_group($key);
                        if ($existing && !empty($existing['ID'])) {
                            $content['ID'] = $existing['ID'];
                        }
                    }
                    acf_import_field_group($content);
                    $synced[] = ['type' => 'field_group', 'key' => $key, 'filename' => $filename];
                } else {
                    $synced[] = ['type' => 'field_group', 'key' => $key, 'filename' => $filename, 'note' => 'JSON saved, manual sync needed'];
                }
            } elseif (strpos($filename, 'post-type_') === 0) {
                // Post Type (ACF PRO)
                if (function_exists('acf_import_post_type')) {
                    // Check if post type already exists by key
                    if (function_exists('acf_get_post_type') && !empty($key)) {
                        $existing = acf_get_post_type($key);
                        if ($existing && !empty($existing['ID'])) {
                            $content['ID'] = $existing['ID'];
                        }
                    }
                    acf_import_post_type($content);
                    $synced[] = ['type' => 'post_type', 'key' => $key, 'filename' => $filename];
                } else {
                    $synced[] = ['type' => 'post_type', 'key' => $key, 'filename' => $filename, 'note' => 'JSON saved, ACF PRO required for auto-import'];
                }
            } elseif (strpos($filename, 'taxonomy_') === 0) {
                // Taxonomy (ACF PRO)
                if (function_exists('acf_import_taxonomy')) {
                    // Check if taxonomy already exists by key
                    if (function_exists('acf_get_taxonomy') && !empty($key)) {
                        $existing = acf_get_taxonomy($key);
                        if ($existing && !empty($existing['ID'])) {
                            $content['ID'] = $existing['ID'];
                        }
                    }
                    acf_import_taxonomy($content);
                    $synced[] = ['type' => 'taxonomy', 'key' => $key, 'filename' => $filename];
                } else {
                    $synced[] = ['type' => 'taxonomy', 'key' => $key, 'filename' => $filename, 'note' => 'JSON saved, ACF PRO required for auto-import'];
                }
            } else {
                $synced[] = ['type' => 'unknown', 'key' => $key, 'filename' => $filename];
            }
        } catch (Exception $e) {
            $errors[] = "Error importing {$filename}: " . $e->getMessage();
        }
    }

    return new WP_REST_Response([
        'success' => empty($errors),
        'synced'  => $synced,
        'errors'  => $errors,
    ]);
}

/**
 * Pull ACF configurations from WordPress to frontend
 */
function acf_sync_pull(): WP_REST_Response {
    $acf_json_path = WP_CONTENT_DIR . '/acf-json/';
    $files = [];

    if (!file_exists($acf_json_path)) {
        return new WP_REST_Response([
            'success' => true,
            'files'   => [],
            'message' => 'No acf-json directory found',
        ]);
    }

    foreach (glob($acf_json_path . '*.json') as $filepath) {
        $content = file_get_contents($filepath);
        $decoded = json_decode($content, true);

        if ($decoded === null) {
            continue;
        }

        $filename = basename($filepath);

        // Determine type from filename
        $type = 'unknown';
        if (strpos($filename, 'group_') === 0) {
            $type = 'field_group';
        } elseif (strpos($filename, 'post-type_') === 0) {
            $type = 'post_type';
        } elseif (strpos($filename, 'taxonomy_') === 0) {
            $type = 'taxonomy';
        }

        $files[] = [
            'filename' => $filename,
            'type'     => $type,
            'content'  => $decoded,
        ];
    }

    return new WP_REST_Response([
        'success' => true,
        'files'   => $files,
    ]);
}

/**
 * Get sync status
 */
function acf_sync_status(): WP_REST_Response {
    $acf_json_path = WP_CONTENT_DIR . '/acf-json/';

    return new WP_REST_Response([
        'success'    => true,
        'acf_active' => function_exists('acf'),
        'acf_pro'    => function_exists('acf_pro'),
        'json_path'  => $acf_json_path,
        'writable'   => is_writable($acf_json_path),
        'file_count' => count(glob($acf_json_path . '*.json')),
    ]);
}

/**
 * Add admin menu for API key configuration
 */
add_action('admin_menu', function () {
    add_options_page(
        'ACF Sync API',
        'ACF Sync API',
        'manage_options',
        'acf-sync-api',
        'acf_sync_api_settings_page'
    );
});

function acf_sync_api_settings_page(): void {
    if (isset($_POST['acf_sync_api_key']) && check_admin_referer('acf_sync_api_settings')) {
        update_option('acf_sync_api_key', sanitize_text_field($_POST['acf_sync_api_key']));
        echo '<div class="notice notice-success"><p>API Key saved!</p></div>';
    }

    $api_key = get_option('acf_sync_api_key', 'dev-key-123');
    ?>
    <div class="wrap">
        <h1>ACF Sync API Settings</h1>
        <form method="post">
            <?php wp_nonce_field('acf_sync_api_settings'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">API Key</th>
                    <td>
                        <input type="text" name="acf_sync_api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text">
                        <p class="description">Used for authentication when syncing from frontend projects.</p>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <button type="submit" class="button button-primary">Save API Key</button>
            </p>
        </form>

        <h2>API Endpoints</h2>
        <table class="widefat">
            <thead>
                <tr>
                    <th>Endpoint</th>
                    <th>Method</th>
                    <th>Description</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><code>/wp-json/acf-sync/v1/push</code></td>
                    <td>POST</td>
                    <td>Push ACF configurations from frontend</td>
                </tr>
                <tr>
                    <td><code>/wp-json/acf-sync/v1/pull</code></td>
                    <td>GET</td>
                    <td>Pull ACF configurations to frontend</td>
                </tr>
                <tr>
                    <td><code>/wp-json/acf-sync/v1/status</code></td>
                    <td>GET</td>
                    <td>Check sync status</td>
                </tr>
            </tbody>
        </table>

        <h3>Usage Example</h3>
        <pre style="background: #f1f1f1; padding: 10px;">
curl -X POST <?php echo home_url('/wp-json/acf-sync/v1/push'); ?> \
  -H "Content-Type: application/json" \
  -H "X-ACF-Sync-Key: <?php echo esc_html($api_key); ?>" \
  -d '{"files": [...]}'
        </pre>
    </div>
    <?php
}
